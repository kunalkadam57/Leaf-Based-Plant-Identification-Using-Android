package com.bvcoe.RecyclerViewAdapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bvcoe.Pojo.HistoryPojo;
import com.bvcoe.uimodule.R;

import java.util.List;

public class HistoryAdapter  extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {

    private List<HistoryPojo> list;
    private OnItemClickListner mListner;


    public interface OnItemClickListner{
        void onViewBtnClick(int position,int id);
    }

    public void setOnClickLisner(OnItemClickListner lisner){
        mListner=lisner;
    }

//    public HistoryAdapter(List<HistoryPojo> list,int []pics){
//        this.list = list;
//        this.pics = pics;
//    }
    public HistoryAdapter(List<HistoryPojo> list){
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View listitem= LayoutInflater.from(parent.getContext()).inflate(R.layout.history_item,parent,false);
        return new ViewHolder(listitem,mListner);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryAdapter.ViewHolder holder, int position) {
        HistoryPojo historyPojo=list.get(getItemCount()-position-1);
        holder.parentLayout.setTag(historyPojo.getId());
        holder.tv_name_of_specie.setText(historyPojo.getName_of_species());
        holder.tv_confidence.setText(historyPojo.getSpecie_confidence());
        holder.tv_date.setText(historyPojo.getDate());
        holder.tv_time.setText(historyPojo.getTime());
        holder.iv_specie_image.setImageBitmap(historyPojo.getImage());
//        TODO add image view of specie and also in pojo
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView tv_name_of_specie, tv_confidence, tv_date, tv_time;
        Button btn_view;
        ImageView iv_specie_image;
        RelativeLayout parentLayout;
        public ViewHolder(@NonNull View itemView,final OnItemClickListner listner) {
            super(itemView);

            tv_name_of_specie=itemView.findViewById(R.id.history_item_tv_name_of_specie);
            tv_confidence=itemView.findViewById(R.id.history_item_tv_confidence_value);
            tv_date=itemView.findViewById(R.id.history_item_tv_date_value);
            tv_time=itemView.findViewById(R.id.history_item_tv_time_value);
            btn_view=itemView.findViewById(R.id.history_item_btn_view);
            iv_specie_image=itemView.findViewById(R.id.history_item_iv_specie_image);

            parentLayout=itemView.findViewById(R.id.history_item_parent_layout);

            btn_view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listner!=null){
                        int position=getAdapterPosition();
                        if (position!=RecyclerView.NO_POSITION){
                            listner.onViewBtnClick(position,Integer.parseInt(parentLayout.getTag().toString()));
                        }
                    }
                }
            });
        }
    }
}
