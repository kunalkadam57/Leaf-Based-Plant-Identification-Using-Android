package com.bvcoe.Fragment;

import android.Manifest;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bvcoe.Classification.Classifier;
import com.bvcoe.Database.DatabaseHelper;
import com.bvcoe.Pojo.HistoryPojo;
import com.bvcoe.Util.Util;
import com.bvcoe.uimodule.MainActivity;
import com.bvcoe.uimodule.R;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


public class HomeFragment extends Fragment implements View.OnClickListener {


    private long pressedTime;
    private DatabaseHelper databaseHelper;
    long res;

    String species_name, confidence, date, time;
    Date d = new Date();
    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm aa");


    public static final int CAMERA_PERM_CODE = 101;
    public static final int CAMERA_REQUEST_CODE = 102;
    public static final int GALLERY_REQUEST_CODE = 103;
    private ImageView iv_plant_image;
    private ImageView iv_hamburger;
    private Button btn_browse;
    private Button btn_camera;
    private Button btn_recognize;
    Bitmap myBitmap;

    private int mInputSize = 224;
    private String mModelPath = "model_unquant.tflite";
    private String mLabelPath = "labels.txt";
    private Classifier classifier;
    private String url;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View view = inflater.inflate(R.layout.fragment_home, container, false);

        ((MainActivity) getActivity()).setCheckedItem(R.id.fragment_container);          //navigation drawer checked item


        try {
            initDatabase();
            initClassifier();
            initViews(view);
            initListner();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return view;
    }


    private void initDatabase() {
        databaseHelper = new DatabaseHelper(getActivity());
    }

    private void initClassifier() throws IOException {
        classifier = new Classifier(getActivity().getAssets(), mModelPath, mLabelPath, mInputSize);
    }

    private void initListner() {
        btn_camera.setOnClickListener(this);
        btn_browse.setOnClickListener(this);
        btn_recognize.setOnClickListener(this);
        iv_hamburger.setOnClickListener(this);
    }

    private void initViews(View view) {
        iv_plant_image = view.findViewById(R.id.dashboard_iv_plant_image);
        iv_hamburger = view.findViewById(R.id.dashboard_iv_hamburger);
        btn_browse = view.findViewById(R.id.dashboard_btn_browse);
        btn_camera = view.findViewById(R.id.dashboard_btn_camera);
        btn_recognize = view.findViewById(R.id.dashboard_btn_recognize);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.dashboard_btn_browse:
                pickGalleryImage();
                break;
            case R.id.dashboard_btn_camera:
                askCameraPermission();
                break;
            case R.id.dashboard_btn_recognize:
                onRecognizeClick();
                break;
            case R.id.dashboard_iv_hamburger:
                ((MainActivity) getActivity()).openDrawer();

        }
    }

    private void onRecognizeClick() {
        Bitmap bitmap = ((BitmapDrawable) ((ImageView) iv_plant_image).getDrawable()).getBitmap();
        List<Classifier.Recognition> result = classifier.recognizeImage(bitmap);
        Log.d("rec", "onRecognizeClick: " + result.size());
        Log.d("rec", "onRecognizeClick: " + result.get(0).toString());

        species_name = result.get(0).title;
        confidence = Float.toString(result.get(0).confidence * 100) + "%";
        date = dateFormat.format(d);
        time = timeFormat.format(d);

        res = databaseHelper.addInference(setValues());
        Log.d("add", "onRecognizeClick: " + res);


//        getURL(result.get(0).title);
        openDialog(result);

//        Toast.makeText(getActivity(),""+url , Toast.LENGTH_SHORT).show();

    }

    private HistoryPojo setValues() {
        Bitmap bitmap = ((BitmapDrawable) ((ImageView) iv_plant_image).getDrawable()).getBitmap();
        HistoryPojo historyPojo = new HistoryPojo();
        historyPojo.setName_of_species(species_name);
        historyPojo.setSpecie_confidence(confidence);
        historyPojo.setDate(date);
        historyPojo.setTime(time);
        historyPojo.setImage(getResizedBitmap(bitmap, 500));
        return historyPojo;
    }

    public Bitmap getResizedBitmap(Bitmap image, int maxSize) {
        int width = image.getWidth();
        int height = image.getHeight();

        float bitmapRatio = (float) width / (float) height;
        if (bitmapRatio > 1) {
            width = maxSize;
            height = (int) (width / bitmapRatio);
        } else {
            height = maxSize;
            width = (int) (height * bitmapRatio);
        }
        return Bitmap.createScaledBitmap(image, width, height, true);
    }


    private void openDialog(List<Classifier.Recognition> result) {
        LayoutInflater inflater = LayoutInflater.from(getActivity());

        View view = inflater.inflate(R.layout.result_dailog, null);

        TextView tv_species_name, tv_confidence;

        Button btn_read_more = view.findViewById(R.id.result_dailog_alert_btn_read_more);
        tv_species_name = view.findViewById(R.id.result_dailog_alert_tv_name_of_species);
        tv_confidence = view.findViewById(R.id.result_dailog_alert_tv_confidence);

        tv_species_name.setText(species_name);
        tv_confidence.setText(confidence);
        url = databaseHelper.getLink(species_name);

        btn_read_more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openBrowser(view);
            }
        });

        AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).setView(view).create();
        alertDialog.show();
    }

    private void openBrowser(View view) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    private void pickGalleryImage() {
        Intent pickImageIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(pickImageIntent, GALLERY_REQUEST_CODE);
    }

    private void askCameraPermission() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        } else {
            openCamera();
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == CAMERA_PERM_CODE) {
            if (grantResults.length < 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            } else {
//                Toast.makeText(this, "Camera Permission not granted.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void openCamera() {
        Intent camIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camIntent, CAMERA_REQUEST_CODE);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case CAMERA_REQUEST_CODE:
                try {
                    myBitmap = (Bitmap) data.getExtras().get("data");
                    iv_plant_image.setImageBitmap(myBitmap);
                } catch (Exception e) {
                    return;
                }
                break;
            case GALLERY_REQUEST_CODE:
                try {
                    Uri contentUri = data.getData();
                    String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                    String imageFileName = "JPEG_" + timestamp + "." + getFileExt(contentUri);
                    iv_plant_image.setImageURI(contentUri);
                } catch (Exception e) {
                    return;
                }

                break;
        }

    }

    private String getFileExt(Uri contentUri) {
        ContentResolver c = getActivity().getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(c.getType(contentUri));
    }
}