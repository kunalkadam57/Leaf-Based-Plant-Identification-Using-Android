package com.bvcoe.Pojo;

import android.graphics.Bitmap;

public class HistoryPojo {
    private int id;
    private String name_of_species;
    private String specie_confidence;
    private String date;
    private String time;
    private Bitmap image;

    public String getName_of_species() {
        return name_of_species;
    }

    public void setName_of_species(String name_of_species) {
        this.name_of_species = name_of_species;
    }

    public String getSpecie_confidence() {
        return specie_confidence;
    }

    public void setSpecie_confidence(String specie_confidence) {
        this.specie_confidence = specie_confidence;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Bitmap getImage() {
        return image;
    }

    public void setImage(Bitmap image) {
        this.image = image;
    }
}
