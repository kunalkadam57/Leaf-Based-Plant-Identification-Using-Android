package com.bvcoe.Util;

import com.bvcoe.Pojo.HistoryPojo;

import java.util.ArrayList;
import java.util.List;

public class Util {



//    database constants
    public static String DATABASE_NAME="LeafEon.db";
//    Species table
    public static String SPECIES_TABLE_NAME="species";

    public static String SPECIES_TABLE_ID="s_id";
    public static String SPECIES_TABLE_SPECIES_NAME="s_name";
    public static String SPECIES_TABLE_SPECIES_LINK="s_link";

//       Inference table
    public static String INFERENCE_TABLE_NAME="inference";

    public static String INFERENCE_TABLE_ID="i_id";
    public static String INFERENCE_TABLE_SPECIES_NAME="i_name";
    public static String INFERENCE_TABLE_CONFIDENCE="i_confidence";
    public static String INFERENCE_TABLE_DATE="i_date";
    public static String INFERENCE_TABLE_TIME="i_time";
    public static String INFERENCE_TABLE_IMAGE="i_image";


}
