package com.bvcoe.Fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bvcoe.Database.DatabaseHelper;
import com.bvcoe.Pojo.HistoryPojo;
import com.bvcoe.RecyclerViewAdapter.HistoryAdapter;
import com.bvcoe.Util.Util;
import com.bvcoe.uimodule.MainActivity;
import com.bvcoe.uimodule.R;

import java.util.List;


public class HistoryFragment extends Fragment implements View.OnClickListener {
    private DatabaseHelper databaseHelper;
    private List<HistoryPojo> historyList;

    private RecyclerView recyclerView;
    private ImageView iv_hamburger;
    HistoryAdapter historyAdapter;
    String url;


    public HistoryFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history, container, false);
        ((MainActivity) getActivity()).setCheckedItem(R.id.nav_history);          //navigation drawer checked item
        onBackPressed(view);

        initDatabase();
        initViews(view);
        initListner();
        populateData();
//        initializeRecycler(Util.listProject);
        return view;
    }

    private void initDatabase() {
        databaseHelper = new DatabaseHelper(getActivity());
    }

    private void initListner() {
        iv_hamburger.setOnClickListener(this);
    }

    private void onBackPressed(View view) {
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.i("##tag", "keyCode: " + keyCode);

                if (keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    //        back press for fragment handled here

                    boolean isdraweropen = ((MainActivity) getActivity()).closeDrawer();
                    Log.e("bool", "onKey: " + isdraweropen);

                    if (isdraweropen) {
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container, new HomeFragment()).commit();
                        ((MainActivity) getActivity()).setCheckedItem(R.id.nav_home);
                    }
                    return true;
                }
                return false;
            }
        });
    }

    private void populateData() {

        historyList = databaseHelper.getAllInferences();
        historyAdapter = new HistoryAdapter(historyList);
        historyAdapter.notifyDataSetChanged();
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(historyAdapter);
        historyAdapter.setOnClickLisner(new HistoryAdapter.OnItemClickListner() {
            @Override
            public void onViewBtnClick(int position, int id) {
                url = databaseHelper.getLink(historyList.get(historyList.size()-position-1).getName_of_species());
                openBrowser();
            }

        });
    }


    private void openBrowser() {
//        Toast.makeText(getActivity(), "" + url, Toast.LENGTH_SHORT).show();

        if (url != null) {
            Uri link = Uri.parse(url);
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, link);
            Log.d("read_more", "openBrowser: " + url);
//            Toast.makeText(getActivity(), ""+url, Toast.LENGTH_SHORT).show();
            startActivity(browserIntent);

        }


    }


    private void initViews(View view) {
        iv_hamburger = view.findViewById(R.id.dashboard_iv_hamburger);
        recyclerView = view.findViewById(R.id.history_rv);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.dashboard_iv_hamburger) {
            ((MainActivity) getActivity()).openDrawer();
        }
    }
}