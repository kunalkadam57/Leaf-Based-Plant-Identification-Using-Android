package com.bvcoe.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import androidx.annotation.Nullable;

import com.bvcoe.Pojo.HistoryPojo;
import com.bvcoe.Util.Util;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper  extends SQLiteOpenHelper {
    private ByteArrayOutputStream byteArrayOutputStream;
    private byte[] imageInByte;

    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_SPECIES="CREATE TABLE "
                + Util.SPECIES_TABLE_NAME + " ("
                + Util.SPECIES_TABLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Util.SPECIES_TABLE_SPECIES_NAME + " text,"
                + Util.SPECIES_TABLE_SPECIES_LINK + " text);";

        String CREATE_TABLE_INFERENCE="CREATE TABLE "
                + Util.INFERENCE_TABLE_NAME + " ("
                + Util.INFERENCE_TABLE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Util.INFERENCE_TABLE_SPECIES_NAME + " text,"
                + Util.INFERENCE_TABLE_CONFIDENCE + " text,"
                + Util.INFERENCE_TABLE_IMAGE + " BLOB,"
                + Util.INFERENCE_TABLE_DATE + " text,"
                + Util.INFERENCE_TABLE_TIME + " text);";

        String INSERT_VALUES="INSERT INTO "+ Util.SPECIES_TABLE_NAME+ " (" + Util.SPECIES_TABLE_SPECIES_NAME+","+Util.SPECIES_TABLE_SPECIES_LINK+")"+
                " VALUES ('Alpinia Galanga (Rasna)','https://en.wikipedia.org/wiki/Alpinia_galanga')" +
                ",('Amaranthus Viridis (Arive-Dantu)','https://en.wikipedia.org/wiki/Amaranthus_viridis')" +
                ",('Artocarpus Heterophyllus (Jackfruit)','https://en.wikipedia.org/wiki/Jackfruit')" +
                ",('Azadirachta Indica (Neem)','https://en.wikipedia.org/wiki/Azadirachta_indica')" +
                ",('Basella Alba (Basale)','https://en.wikipedia.org/wiki/Basella_alba')" +
                ",('Brassica Juncea (Indian Mustard)','https://en.wikipedia.org/wiki/Brassica_juncea')" +
                ",('Carissa Carandas (Karanda)','https://en.wikipedia.org/wiki/Carissa_carandas')" +
                ",('Citrus Limon (Lemon)','https://en.wikipedia.org/wiki/Lemon')" +
                ",('Ficus Auriculata (Roxburgh fig)','https://en.wikipedia.org/wiki/Ficus_auriculata')" +
                ",('Ficus Religiosa (Peepal Tree)','https://en.wikipedia.org/wiki/Ficus_religiosa')" +
                ",('Hibiscus Rosa-sinensis','https://en.wikipedia.org/wiki/Hibiscus_rosa-sinensis')" +
                ",('Jasminum (Jasmine)','https://en.wikipedia.org/wiki/Jasmine')" +
                ",('Mangifera Indica (Mango)','https://en.wikipedia.org/wiki/Mangifera_indica')" +
                ",('Mentha (Mint)','https://en.wikipedia.org/wiki/Mentha')" +
                ",('Moringa Oleifera (Drumstick)','https://en.wikipedia.org/wiki/Moringa_oleifera')" +
                ",('Muntingia Calabura (Jamaica Cherry-Gasagase)','https://en.wikipedia.org/wiki/Muntingia')" +
                ",('Murraya Koenigii (Curry)','https://en.wikipedia.org/wiki/Curry_tree')" +
                ",('Nerium Oleander (Oleander)','https://en.wikipedia.org/wiki/Nerium')" +
                ",('Nyctanthes Arbor-tristis (Parijata)','https://en.wikipedia.org/wiki/Nyctanthes_arbor-tristis')" +
                ",('Ocimum Tenuiflorum (Tulsi)','https://en.wikipedia.org/wiki/Ocimum_tenuiflorum')" +
                ",('Piper Betle (Betel)','https://en.wikipedia.org/wiki/Betel')" +
                ",('Plectranthus Amboinicus (Mexican Mint)','https://en.wikipedia.org/wiki/Coleus_amboinicus')" +
                ",('Pongamia Pinnata (Indian Beech)','https://en.wikipedia.org/wiki/Millettia_pinnata')" +
                ",('Psidium Guajava (Guava)','https://en.wikipedia.org/wiki/Psidium_guajava')" +
                ",('Punica Granatum (Pomegranate)','https://en.wikipedia.org/wiki/Pomegranate')" +
                ",('Santalum Album (Sandalwood)','https://en.wikipedia.org/wiki/Santalum_album')" +
                ",('Syzygium Cumini (Jamun)','https://en.wikipedia.org/wiki/Syzygium_cumini')" +
                ",('Syzygium Jambos (Rose Apple)','https://en.wikipedia.org/wiki/Syzygium_jambos')" +
                ",('Tabernaemontana Divaricata (Crape Jasmine)','https://en.wikipedia.org/wiki/Tabernaemontana_divaricata')" +
                ",('Trigonella Foenum-graecum (Fenugreek)','https://en.wikipedia.org/wiki/Fenugreek');";


        db.execSQL(CREATE_TABLE_SPECIES);
        db.execSQL(CREATE_TABLE_INFERENCE);
        db.execSQL(INSERT_VALUES);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public String getLink(String s_name)
    {
        SQLiteDatabase db= getReadableDatabase();
        String url = null;
        Cursor cursor=db.rawQuery("select "+Util.SPECIES_TABLE_SPECIES_LINK+" from "+Util.SPECIES_TABLE_NAME+" where "+ Util.SPECIES_TABLE_SPECIES_NAME+"='"+s_name+"'",null);
        if (cursor !=null && cursor.moveToFirst())
        {
            url=cursor.getString(cursor.getColumnIndex(Util.SPECIES_TABLE_SPECIES_LINK));
        }
        return url;
    }

    public long addInference(HistoryPojo historyPojo)
    {
        long inferenceId;

        Bitmap bitmap=historyPojo.getImage();
        byteArrayOutputStream=new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,byteArrayOutputStream);
        imageInByte=byteArrayOutputStream.toByteArray();


        SQLiteDatabase db=getWritableDatabase();

        ContentValues contentValues=new ContentValues();
        contentValues.put(Util.INFERENCE_TABLE_SPECIES_NAME,historyPojo.getName_of_species());
        contentValues.put(Util.INFERENCE_TABLE_CONFIDENCE,historyPojo.getSpecie_confidence());
        contentValues.put(Util.INFERENCE_TABLE_DATE,historyPojo.getDate());
        contentValues.put(Util.INFERENCE_TABLE_TIME,historyPojo.getTime());
        contentValues.put(Util.INFERENCE_TABLE_IMAGE,imageInByte);

        inferenceId=db.insert(Util.INFERENCE_TABLE_NAME,null,contentValues);
        db.close();
        return  inferenceId;
    }

    public List<HistoryPojo> getAllInferences(){
        List<HistoryPojo> historylist=new ArrayList<>();
        SQLiteDatabase db=getReadableDatabase();
        Cursor cursor=db.query(Util.INFERENCE_TABLE_NAME,null,null,null,null,null,null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                HistoryPojo historyPojo = new HistoryPojo();
                byte[] imageBytes=cursor.getBlob(cursor.getColumnIndex(Util.INFERENCE_TABLE_IMAGE));
                Bitmap bitmap= BitmapFactory.decodeByteArray(imageBytes,0,imageBytes.length);

                historyPojo.setId(cursor.getInt(cursor.getColumnIndex(Util.INFERENCE_TABLE_ID)));
                historyPojo.setName_of_species(cursor.getString(cursor.getColumnIndex(Util.INFERENCE_TABLE_SPECIES_NAME)));
                historyPojo.setSpecie_confidence(cursor.getString(cursor.getColumnIndex(Util.INFERENCE_TABLE_CONFIDENCE)));
                historyPojo.setDate(cursor.getString(cursor.getColumnIndex(Util.INFERENCE_TABLE_DATE)));
                historyPojo.setTime(cursor.getString(cursor.getColumnIndex(Util.INFERENCE_TABLE_TIME)));
                historyPojo.setImage(bitmap);
                historylist.add(historyPojo);
            } while (cursor.moveToNext());
        }
        return historylist;
    }
}
