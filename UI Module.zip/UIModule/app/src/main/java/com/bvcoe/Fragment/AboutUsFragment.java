package com.bvcoe.Fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.bvcoe.uimodule.MainActivity;
import com.bvcoe.uimodule.R;


public class AboutUsFragment extends Fragment implements View.OnClickListener {

    private ImageView iv_hamburger;

    public AboutUsFragment() {
        // Required empty public constructor
    }





    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.fragment_about_us,container,false);
        ((MainActivity)getActivity()).setCheckedItem(R.id.nav_aboutUs);          //navigation drawer checked item
        onBackPressed(view);
        initViews(view);
        initListner();
        return view;
    }

    private void initListner() {
        iv_hamburger.setOnClickListener(this);
    }

    private void initViews(View view) {
        iv_hamburger=view.findViewById(R.id.dashboard_iv_hamburger);
    }

    private void onBackPressed(View view) {
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                Log.i("##tag", "keyCode: " + keyCode);

                if( keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
                    //        back press for fragment handled here

                    boolean isdraweropen=((MainActivity)getActivity()).closeDrawer();
                    Log.e("bool", "onKey: "+isdraweropen);

                    if(isdraweropen) {
                        getFragmentManager().beginTransaction().replace(R.id.fragment_container,new HomeFragment()).commit();
                        ((MainActivity)getActivity()).setCheckedItem(R.id.nav_home);
                    }
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()){
            case R.id.dashboard_iv_hamburger:
                ((MainActivity)getActivity()).openDrawer();
        }
    }
}